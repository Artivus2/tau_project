<?php

namespace app\models;

use Yii;
use yii\base\Model;
use app\models\Company;
use app\models\Otdel;
use app\models\Ruk;

/**
 * ContactForm is the model behind the contact form.
 */
class ContactForm extends \yii\db\ActiveRecord
{
    public $company = null;
     public $otdel = null;
     public $ruk = null;
     public $subject = null;
     public $body = null;    
    //public $verifyCode;

    public static function tableName()
    {
        return 'subject';
    }
    /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            // name, email, subject and body are required
            [['company', 'otdel', 'ruk','subject', 'body'], 'required'],
            // email has to be a valid email address
            // verifyCode needs to be entered correctly
            //['verifyCode', 'captcha'],
        ];
    }

    /**
     * @return array customized attribute labels
     */
    public function attributeLabels()
    {
        return [
            'company' => 'Название организации',
            'otdel' => 'Название отдела',
            'ruk' => 'ФИО Руководителя/ответственного',
            'subject' => 'Тема обращения',
            'body' => 'Текст обращения'

        ];
    }

    /**
     * Sends an email to the specified email address using the information collected by this model.
     * @param string $email the target email address
     * @return bool whether the model passes validation
     */
    public function contact()
    {
        
        //     Yii::$app->mailer->compose()
        //         ->setTo($email)
        //         ->setFrom([Yii::$app->params['senderEmail'] => Yii::$app->params['senderName']])
        //         ->setReplyTo([$this->email => $this->name])
        //         ->setSubject($this->subject)
        //         ->setTextBody($this->body)
        //         ->send();

    }

    public function getCompany()
    {
        return $this->hasOne(Company::class, ['id' => 'company_id']);
    }
}
