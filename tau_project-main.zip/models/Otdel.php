<?php

namespace app\models;

use Yii;
/**
 * @SWG\Definition()
 *
 * @SWG\Property(property="id", type="integer", description="ID")
 * @SWG\Property(property="company_id", type="string", description="id company")
 * @SWG\Property(property="name", type="string", description="Наименование")
 */
class Otdel extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'otdel';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id','company_id'], 'required'],

            [['name'], 'string'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'company_id' => 'Организация',
            'name' => 'Наименование',
        ];
    }


    public function getCompany()
    {
        return $this->hasOne(Company::class, ['id' => 'company_id']);
    }

    

}