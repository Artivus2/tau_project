<?
if (extension_loaded('sockets'))
    echo "WebSockets OK";
else
    echo "WebSockets UNAVAILABLE";